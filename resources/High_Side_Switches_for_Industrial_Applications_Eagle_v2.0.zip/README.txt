README.txt

For further assistance, please contact Ask Infineon

Germany: 0800 951 951 951 (German/English) 

China, Mainland: 4001 200 951 (Mandarin/English) 

USA: 1 866 951 9519 (English/German) 

India: 000 800 4402 951 (English) 

Direct Access: +49 89 234 65555 (German/English) 

International toll-free 0800 service 00** 800 951 951 951 

or email: Product-Services-Hotline@infineon.com



----------------------------------------------------------------------

Version 	Date			Changes / Remark

v1			2013-09-30		initial revision

v2			2013-10-21		added new components

	Details:
		Added new component: ITS42008-SB-D
		Added new component: ITS4142N
		Added new component: ITS4141N
		Added new component: ISP762T
		Added new component: ITS4140N
		Added new component: ITS4880R
		Added new component: ITS4200S-ME-N
		Added new component: ITS4300S-SJ-D
		Added new component: ITS4100S-SJ-N
		Added new component: ITS4200S-ME-P
		Added new component: ISP752R
		Added new component: ITS4141D
		Added new component: ITS4200S-SJ-D
		Added new component: ITS4200S-ME-O
		Added new component: ISP772T
		Added new component: ITS4060S-SJ-N
		Added new component: ISP752T
		Added new component: ISP742RI
		Added new component: ITS41K0S-ME-N

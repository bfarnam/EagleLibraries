Windows 2000, XP, or Vista is REQUIRED to run this software, as well as Microsoft's .NET Redistributable Framework v2.0 or newer. NOTE: if you are using Windows 2000 and are having problems, our support will likely be extremely limited as Microsoft no longer supports Windows 2000.

The .NET Framework v2.0 can be downloaded for free from Microsoft�s website at:
http://www.microsoft.com/downloads/details.aspx?FamilyID=0856EACB-4362-4B0D-8EDD-AAB15C5E04F5&displaylang=en

If this link is no longer good, you can alternatively go to http://www.Microsoft.com and type �.NET Framework redistributable� in the search query to bring up the new page. If you use a language other than English, be sure to change the setting!


